/*
 * s3-b_Scan.h
 *
 *  Created on: Oct 31, 2020
 *      Author: trg1
 */



#ifndef S3_B_SCAN_H_
#define S3_B_SCAN_H_


void s3_b_init();

double s3_b_Scan(double angle);

#endif /* S3_B_SCAN_H_ */
