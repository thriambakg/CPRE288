/*
 * autoScan.h
 *
 *  Created on: Nov 5, 2020
 *      Author: trg1
 */

#ifndef AUTOSCAN_H_
#define AUTOSCAN_H_

void scaninit(void);
void scan(int move_to);

#endif /* AUTOSCAN_H_ */
