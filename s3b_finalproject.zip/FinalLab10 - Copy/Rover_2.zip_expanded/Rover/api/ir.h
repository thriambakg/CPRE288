#ifndef IR_H_
#define IR_H_

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inc/tm4c123gh6pm.h>

void ir_timer_init();
int ir_read();


#endif /* IR_H_ */
