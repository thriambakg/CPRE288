/**
 * lab4_template.c
 * 
 * Template file for CprE 288 lab 4
 *
 * @author Zhao Zhang, Chad Nelson, Zachary Glanz
 * @date 08/14/2016
 *
 * @author Phillip Jones, updated 6/4/2019
 */

#include "lcd.h"
#include "button.h"
#include "movement.h"
#include "open_interface.h"
#include "Timer.h"
#include "resetSimulation.h"
#include <string.h>
#include <stdio.h>

#include "cyBot_uart.h"  // Functions for communiticate between CyBot and Putty (via UART)
// PuTTy: Buad=115200, 8 data bits, No Flow Control, No Party,  COM1

#include "cyBot_Scan.h"  // For scan sensors 

#warning "Possible unimplemented functions"
#define REPLACEME 0

// Defined in button.c : Used to communicate information between the
// the interupt handeler and main.
extern volatile int button_event;
extern volatile int button_num;

int main(void)
{

    //button_init();
    lcd_init();
    //init_button_interrupts(button_event, button_num);




    cyBot_uart_init_clean(); // Clean UART initialization, before running your UART GPIO init code

    SYSCTL_RCGCGPIO_R |= 0x00000002;
    timer_waitMillis(1); // Small delay before accessing device after turning on clock
    GPIO_PORTB_AFSEL_R |= 0x03;
    GPIO_PORTB_PCTL_R &= 0xFFFFFFEE;     // Force 0's in the desired locations
    GPIO_PORTB_PCTL_R |= 0x00000011;     // Force 1's in the desired locations
    GPIO_PORTB_DEN_R |= 0b00000011;
    GPIO_PORTB_DIR_R &= 0b11111110;      // Force 0's in the desired locations
    GPIO_PORTB_DIR_R |= 0b00000010;      // Force 1's in the desired locations

    cyBot_uart_init_last_half();  // Complete the UART device initialization part of configuration

    // Initialze scan sensors
    //cyBOT_init_Scan();

    // YOUR CODE HERE


    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    char value;
    while (true)
    {

        value = cyBot_getByte_blocking();
        if (value == 'w')
        {
            move_forward(sensor_data, 1);
        }
        else if (value == 'd')
        {
            turn_left(sensor_data, 1);
        }
        else if (value =='a')
        {
            turn_right(sensor_data, 1);
        }
        else if (value =='s')
        {
            move_backward(sensor_data, -1);
        }

    }
    oi_free(sensor_data);

}
