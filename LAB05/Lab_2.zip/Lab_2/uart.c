/*
*
*   uart.c
*
*
*
*
*
*   @author
*   @date
*/

#include "uart.h"

void uart_init(void){
	//TODO
}

void uart_sendChar(char data){
	//TODO
}

int uart_receive(void){
	//TODO
}

void uart_sendStr(const char *data){
	//TODO for reference see lcd_puts from lcd.c file
}
